#include <Arduino.h>

const int led1=0;  //PB0
const int led2=1;  //PB1
const int SD_CS=2; //PB2

const int NVC_RES=20;  //PC4
const int NVC_PPS=21;  //PC5
const int NVC_ANT=22;  //PC6
const int NVC_SLP=23;  //PC7
const int USB_BDR=9600;
const int UARTB_DEF_BDR=19200;
const int NVC_MOD=0;
