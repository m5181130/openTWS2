#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#define NUM_DIGITAL_PINS            32
#define NUM_ANALOG_INPUTS           8
#define analogInputToDigitalPin(p)  ((p < NUM_ANALOG_INPUTS) ? (p) + 24 : -1)
#define digitalPinHasPWM(p)         ((p) == 3 || (p) == 4 || (p) == 12 || \
                                     (p) == 13 || (p) == 14 || (p) == 15)

static const uint8_t SS   = 4;
static const uint8_t MOSI = 5;
static const uint8_t MISO = 6;
static const uint8_t SCK  = 7;

static const uint8_t SDA = 17;
static const uint8_t SCL = 16;
#define LED_BUILTIN 0

static const uint8_t A0 = 24;
static const uint8_t A1 = 25;
static const uint8_t A2 = 26;
static const uint8_t A3 = 27;
static const uint8_t A4 = 28;
static const uint8_t A5 = 29;
static const uint8_t A6 = 30;
static const uint8_t A7 = 31;

#define digitalPinToPCICR(p)    ( ((p) >= 0 && (p) < NUM_DIGITAL_PINS) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p) ( ((p) <= 7) ? 1 : \
                                  ( ((p) <= 15) ? 3 : \
                                    ( ((p) <= 23) ? 2 : 0)))
#define digitalPinToPCMSK(p)    ( ((p) <= 7) ? (&PCMSK1) : \
                                  ( ((p) <= 15) ? (&PCMSK3) : \
                                    ( ((p) <= 23) ? (&PCMSK2) : \
                                      ( ((p) <= 31) ? (&PCMSK0) : \
                                        ( (uint8_t *)0 )))))
#define digitalPinToPCMSKbit(p) ((p) % 8)
#define digitalPinToInterrupt(p)  ( (p) == 10 ? 0 : ((p) == 11 ? 1 : \
                                    ( (p) == 2 ? 2 : NOT_AN_INTERRUPT)))

#ifdef ARDUINO_MAIN

const uint16_t PROGMEM port_to_mode_PGM[] =
{
    NOT_A_PORT,
    (uint16_t) &DDRA,
    (uint16_t) &DDRB,
    (uint16_t) &DDRC,
    (uint16_t) &DDRD,
};

const uint16_t PROGMEM port_to_output_PGM[] =
{
    NOT_A_PORT,
    (uint16_t) &PORTA,
    (uint16_t) &PORTB,
    (uint16_t) &PORTC,
    (uint16_t) &PORTD,
};

const uint16_t PROGMEM port_to_input_PGM[] =
{
    NOT_A_PORT,
    (uint16_t) &PINA,
    (uint16_t) &PINB,
    (uint16_t) &PINC,
    (uint16_t) &PIND,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] =
{
    PB, /* 0 */
    PB,
    PB,
    PB,
    PB,
    PB,
    PB,
    PB,
    PD, /* 8 */
    PD,
    PD,
    PD,
    PD,
    PD,
    PD,
    PD,
    PC, /* 16 */
    PC,
    PC,
    PC,
    PC,
    PC,
    PC,
    PC,
    PA, /* 24 */
    PA,
    PA,
    PA,
    PA,
    PA,
    PA,
    PA  /* 31 */
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] =
{
    _BV(0), /* 0, port B */
    _BV(1),
    _BV(2),
    _BV(3),
    _BV(4),
    _BV(5),
    _BV(6),
    _BV(7),
    _BV(0), /* 8, port D */
    _BV(1),
    _BV(2),
    _BV(3),
    _BV(4),
    _BV(5),
    _BV(6),
    _BV(7),
    _BV(0), /* 16, port C */
    _BV(1),
    _BV(2),
    _BV(3),
    _BV(4),
    _BV(5),
    _BV(6),
    _BV(7),
    _BV(0), /* 24, port A */
    _BV(1),
    _BV(2),
    _BV(3),
    _BV(4),
    _BV(5),
    _BV(6),
    _BV(7)
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] =
{
    NOT_ON_TIMER,    /* 0  - PB0 */
    NOT_ON_TIMER,    /* 1  - PB1 */
    NOT_ON_TIMER,    /* 2  - PB2 */
    TIMER0A,         /* 3  - PB3 */
    TIMER0B,         /* 4  - PB4 */
    NOT_ON_TIMER,    /* 5  - PB5 */
    NOT_ON_TIMER,    /* 6  - PB6 */
    NOT_ON_TIMER,    /* 7  - PB7 */
    NOT_ON_TIMER,    /* 8  - PD0 */
    NOT_ON_TIMER,    /* 9  - PD1 */
    NOT_ON_TIMER,    /* 10 - PD2 */
    NOT_ON_TIMER,    /* 11 - PD3 */
    TIMER1B,         /* 12 - PD4 */
    TIMER1A,         /* 13 - PD5 */
    TIMER2B,         /* 14 - PD6 */
    TIMER2A,         /* 15 - PD7 */
    NOT_ON_TIMER,    /* 16 - PC0 */
    NOT_ON_TIMER,    /* 17 - PC1 */
    NOT_ON_TIMER,    /* 18 - PC2 */
    NOT_ON_TIMER,    /* 19 - PC3 */
    NOT_ON_TIMER,    /* 20 - PC4 */
    NOT_ON_TIMER,    /* 21 - PC5 */
    NOT_ON_TIMER,    /* 22 - PC6 */
    NOT_ON_TIMER,    /* 23 - PC7 */
    NOT_ON_TIMER,    /* 24 - PA0 */
    NOT_ON_TIMER,    /* 25 - PA1 */
    NOT_ON_TIMER,    /* 26 - PA2 */
    NOT_ON_TIMER,    /* 27 - PA3 */
    NOT_ON_TIMER,    /* 28 - PA4 */
    NOT_ON_TIMER,    /* 29 - PA5 */
    NOT_ON_TIMER,    /* 30 - PA6 */
    NOT_ON_TIMER     /* 31 - PA7 */
};

#endif // ARDUINO_MAIN
#endif // Pins_Arduino_h
